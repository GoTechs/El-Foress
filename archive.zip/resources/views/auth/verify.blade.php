
    @extends('../layout')

    @section('content')

    <!-- Content section Start --> 
    <section id="content">
      <div class="container">

       
            <div class="row">
                <div class="alert alert-success col-xs-4 col-xs-offset-4">
                    <strong>Un email a été envoyé à l'adresse fournie. Veuillez suivre les instructions dans l'email pour vous inscrire.</strong>
                </div>
            </div>
        

        </div>
      </div>
    </section>
    <!-- Content section End -->

    @endsection
