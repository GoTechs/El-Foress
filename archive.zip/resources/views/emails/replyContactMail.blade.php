@component('mail::message')


Bonjour {{$name}},

Votre message a bien été envoyé à notre équipe de support client! Un représentant de Foress répondra à votre demande sous peu.

Si vous souhaitez mettre à jour votre message, vous pouvez le faire en répondant à cet e-mail.

Meilleures salutations,

L'équipe Foress

@endcomponent





