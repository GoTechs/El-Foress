
@extends('layout')

@section('content')

  <!-- Start Content -->
  <div id="content">
    <div class="container">        
      <div class="row">
        <div class="col-md-12">              

            <div class="alert alert-warning" role="alert">
                Désolé, Nous ne pouvons pas accéder a cette information pour l'instant. Merci de réessayer plus tard.
               
            </div>

        </div>      
      </div>
    </div>      
  </div>

  <!-- End Content -->

@endsection