
@extends('layout')

@section('content')

  <!-- Start Content -->
  <div id="content">
    <div class="container">        
      <div class="row">
        <div class="col-md-12">              

            <div class="alert alert-warning" role="alert">
                Bon, il semblerait que la page n'existe plus.
                La page a sûrement été retirée ou le lien URL a une petite faute.
                <a href='/'><strong> Retour à la page d'accueil</strong></a> 
            </div>

        </div>      
      </div>
    </div>      
  </div>

  <!-- End Content -->

@endsection