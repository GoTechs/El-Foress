<?php

return [

    'home_page_title' => 'Informations personnels',
    'last_name_input' => 'Nom',
    'first_name_input' => 'Prénom',
    'email_input' => 'Email',
    'adresse_input' => 'Adresse',
    'phone_input' => 'Numéro de téléphone',
    'setting_title' => 'Paramètres',
    'password_input' => 'Nouveau mot de passe',
    'confirm_password_input' => 'Confirmation',
    'update_button' => 'Modifier',

];