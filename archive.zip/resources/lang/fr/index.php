<?php

return [

    'welcome_message' => 'Bienvenue à',
    'description_message' => 'Notre mission vous simplifier la vie',
    'categorie_input' => 'Toutes les catégories',
    'wilaya_input' => 'Wilaya',
    'keyword_input' => "Rechercher n'importe quoi...",
    'search_button' => 'Recherche',
    'category_all' => 'Toutes les catégories',
    'category_community' => 'Communauté',
    'category_job' => 'Emplois',
    'category_real_estat' => 'Immobiliers',
    'category_car' => 'Véhicules',
    'category_shop' => 'Boutiques',
    'category_house_hold' => 'Électroménagers',
    'category_service' => 'Services',
    'category_computer_science' => 'Matériel informatique',
    'category_travel' => 'Voyages',
    'category_animals' => 'Animaux',
    'category_other' => 'Autres',
    'most_visited_ad' => 'Populaire dans Acheter et Vendre',
    'number_visitors' => 'Nombre de visiteurs',
    'number_ads' => 'Nombre d\'annonces',
    'ads_premium' => 'Annonces Premium',

];