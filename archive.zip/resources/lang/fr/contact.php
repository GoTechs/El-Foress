<?php

return [

    'contact_tiltle' => 'contactez nous',
    'contact_message' => 'Comment pouvons-nous vous aider ?',
    'name_input' => 'Nom complet',
    'adresse_email_input' => 'Adresse mail',
    'subject_input' => 'Sujet',
    'message_input' => 'Message',
    'submit_input' => 'Envoyez votre message',
    'contact_information' => 'Contact Information',
    'adresse_info' => 'Adresse',
    'adresse_one' => '9 Rue des 8 mètres coop.el.nasr point du jour.',
    'adresse_two' => 'Oran, Algérie',
    'phone_info' => 'Numéro de téléphone',
    'phone' => '0669-57-69-08',
    'adresse_email_info' => 'Adresse Mail',
    'adresse_email' => 'contact.foress@gmail.com',

];