<?php

return [

    'title_page' => 'Foress',
    'login_button' => '',
    'register_button' => '',
    'post_button' => '',
    'category_button' => '',
    'description_title' => '',
    'description_text' => '',
    'name_app' => '',
    'index_menu' => '',
    'contact_menu' => '',
    'about_menu' => '',
    'faq_menu' => '',
    'login_menu' => '',
    'register_menu' => '',
    'category_menu' => '',
    'about_menu' => '',
    'recently_add' => '',
    'about_menu' => '',
    'about_menu' => '',
    'about_menu' => '',
    'about_menu' => '',
    'about_menu' => '',
    'about_menu' => '',
    'about_menu' => '',
    'about_menu' => '',
    'about_menu' => '',

];
