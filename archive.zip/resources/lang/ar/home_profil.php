<?php

return [

    'home_page_title' => 'المعلومات الشخصية',
    'last_name_input' => 'اللقب',
    'first_name_input' => 'الاسم',
    'email_input' => 'البريد الإلكتروني',
    'adresse_input' => 'العنوان',
    'phone_input' => 'رقم الهاتف',
    'setting_title' => 'الإعدادات',
    'password_input' => 'كلمة سر جديدة',
    'confirm_password_input' => 'تأكيد كلمة السر',
    'update_button' => 'تغيير',

];