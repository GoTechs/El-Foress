<?php

return [

    'contact_tiltle' => 'اتصل بنا',
    'contact_message' => 'إذا كان لديك أي أسئلة، لا تتردد في الاتصال بنا.',
    'name_input' => 'الاسم الكامل',
    'adresse_email_input' => 'البريد الالكتروني',
    'subject_input' => 'الموضوع',
    'message_input' => 'الرسالة',
    'submit_input' => 'إرسال',
    'contact_information' => 'اتصل بنا عبر ',
    'adresse_info' => 'العنوان',
    'adresse_one' => '9 شارع مطلع الفجر.',
    'adresse_two' => 'وهران ، الجزائر',
    'phone_info' => 'رقم الهاتف',
    'phone' => '0669-57-69-08',
    'adresse_email_info' => 'البريد الإلكتروني',
    'adresse_email' => 'contact.foress@gmail.com',

];