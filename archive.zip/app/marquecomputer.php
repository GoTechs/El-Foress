<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class marquecomputer extends Model
{
    protected $table = 'marquecomputers';

    protected $guarded = [];
}
