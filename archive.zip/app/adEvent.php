<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adEvent extends Model
{
    protected $table = 'ad_events';

    protected $guarded = [];
}
