<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class favoris extends Model
{
    protected $table = 'favoris';

    protected $guarded = [];
}
