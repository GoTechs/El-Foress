<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adPhone extends Model
{
    protected $table = 'ad_phones';

    protected $guarded = [];
}
