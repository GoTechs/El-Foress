<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class domainemploi extends Model
{
    protected $table = 'domainemplois';

    protected $guarded = [];
}
