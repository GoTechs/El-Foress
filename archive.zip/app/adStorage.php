<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adStorage extends Model
{
    protected $table = 'ad_storages';

    protected $guarded = [];

}
