<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class typebien extends Model
{
    protected $table = 'typebiens';

    protected $guarded = [];
}
