<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class marqueveh extends Model
{
    protected $table = 'marquevehs';

    protected $guarded = [];
}
