<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adCar extends Model
{
    protected $table = 'ad_cars';

    protected $guarded = [];
}
