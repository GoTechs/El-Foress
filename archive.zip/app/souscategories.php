<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class souscategories extends Model
{
    protected $table = 'souscategories';

    protected $guarded = [];
}
