<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelForess extends Model
{
    //
}
