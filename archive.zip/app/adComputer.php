<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adComputer extends Model
{
    protected $table = 'ad_computers';

    protected $guarded = [];
}
