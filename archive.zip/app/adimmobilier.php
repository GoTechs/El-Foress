<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adimmobilier extends Model
{
    protected $table = 'adimmobiliers';

    protected $guarded = [];
}
