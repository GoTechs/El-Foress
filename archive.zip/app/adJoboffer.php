<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adJoboffer extends Model
{
    protected $table = 'ad_joboffers';

    protected $guarded = [];
}
