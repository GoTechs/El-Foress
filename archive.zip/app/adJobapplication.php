<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adJobapplication extends Model
{
    protected $table = 'ad_jobapplications';

    protected $guarded = [];
}
